import { Component } from '@angular/core';

@Component({
  selector: 'app-showuser',
  templateUrl: './showuser.component.html',
  styleUrl: './showuser.component.css'
})
export class ShowuserComponent {
  user_records:any[]=[];
  data={
     name:"",
     email:"",
     password:"",
     mobile:"",
     address:""
  }
constructor(){
  this.user_records=JSON.parse(localStorage.getItem("users") || "{}");
}
}
